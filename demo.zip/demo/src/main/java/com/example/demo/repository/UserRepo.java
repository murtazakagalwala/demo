package com.example.demo.repository;


import java.util.Optional;

import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.example.demo.entities.Users;

public interface UserRepo extends JpaRepository<Users,Long> {
	
	@Query("select ua.Users_id from UserAccount ua where ua.AccNo=:Accno")
	long findByAccno(@Param("Accno") long accno);
		
	@Query("select u from Users u,UserAccount ua where u.id=ua.Users_id and ua.AccNo=:Accno")
	Optional<Users> findUserByAccno(@Param("Accno") long accno);	
	
	@Transactional
	@Modifying(clearAutomatically = true)
	@Query("update UserAccount ua SET ua.AccNo=:accno where ua.Users_id=:id and ua.accType=:type")
	void UpdateUserAccno(@Param("id") long id,@Param("accno") long accno,@Param("type") int type);
}
