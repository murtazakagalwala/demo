package com.example.demo.controller;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Optional;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.aspects.RequestLogger;
import com.example.demo.entities.UserAccount;
import com.example.demo.entities.UserPhone;
import com.example.demo.entities.Users;
import com.example.demo.repository.UserRepo;



@RestController
@RequestMapping(path="/demo")
public class UserController {
	
	@Autowired
	private UserRepo ur;

	
	@GetMapping(path="/get")
	public List<Users> GetUsers() {
		return ur.findAll();
			
	}
	
	//Indirect User Fetching
	//......................................................
	//......................................................
	@GetMapping(path="/getAccountDetails/{Accountnumber}")
	@ResponseBody
	public Optional<Users> GetUserAccount(@PathVariable("Accountnumber") long accno) {
		long id=ur.findByAccno(accno);
		Optional<Users> user=ur.findById(id);
		return user;			
	}
	//......................................................
	//......................................................
	//Indirect User Fetching Ends

	
	
	//Direct User Fetching
	//......................................................
	//......................................................
	@GetMapping(path="/getAccountDetailsUser/{Accountnumber}")
	@ResponseBody
	public Optional<Users> GetUserAccountdirectly(@PathVariable("Accountnumber") long accno) {
		Optional<Users> user=ur.findUserByAccno(accno);
		return user;		
	}
	//......................................................
	//......................................................
	//Direct User Fetching Ends
	
	
	
	
	@PostMapping(path="/add")
	public ResponseEntity<String> AddUser(@RequestBody Users user) {
		ur.save(user);		
		 return new ResponseEntity<String>(HttpStatus.CREATED);
	}
	
	

	
	@PostMapping(path="/addparam")
	public String AddUserparam() {
		Users user=new Users();
		
		UserPhone uphone=new UserPhone();
		uphone.setPhonenumber(656742675);
		UserPhone uphone2=new UserPhone();
		uphone2.setPhonenumber(656742674);
		Set<UserPhone> upset=new HashSet<UserPhone>();
		
		UserAccount uacc=new UserAccount();
		uacc.setAccNo(123410);
		uacc.setAccType(1);
		uacc.setBalance(5000.0);
		
		UserAccount uacc2=new UserAccount();
		uacc2.setAccNo(123411);
		uacc2.setAccType(0);
		uacc2.setBalance(5000.0);
		
		Set<UserAccount> uaccset=new HashSet<UserAccount>();
		uaccset.add(uacc);
		uaccset.add(uacc2);
		upset.add(uphone);
		upset.add(uphone2);
		user.setName("Shabbir");
		user.setLastName("Kagalwala");
		user.setPhonenumber(upset);
		user.setAccno(uaccset);
		ur.save(user);		
		return "Created";
		
	}
	
	
	
	
	
	@DeleteMapping(path="/delete/{name}")
	public void DelUser(@PathVariable("name") String name) {
		
		List<Users> userlist=new ArrayList<Users>();
		userlist=ur.findAll();
		if(userlist !=null) {
		for(Users usr: userlist) {
			if(usr.getName().equals(name)) {
				ur.delete(usr);
				System.out.println("Deleted");
			}
			
			else {
				System.out.println("User Not Found");
			}
		}
		}
		else
		{
			System.out.println("No Users Available in DB");
		}
	}
	
	
	
	
	
	@PutMapping(path="/update-user-savingaccountno/{id}")
	public void UpdateUser(@PathVariable("id") long id,@RequestParam long accno) {
		
		List<Users> userlist=new ArrayList<Users>();
		userlist=ur.findAll();
		if(userlist !=null) {
			for(Users usr: userlist) {
				if(usr.getId()==id) {
				UserAccount ac=new UserAccount();
				ac.setAccNo(accno);
				Set<UserAccount> set=new HashSet<UserAccount>();
				ac.setAccType(1);
				set.add(ac);
				usr.setAccno(set);
				ur.save(usr);
				System.out.println("updated");
				}			
			}
		}	
	}
	
	
	
	@PutMapping(path="/update-user-accountno/{id}")
	public void UpdateUser(@PathVariable("id") long id,@RequestParam long accno,@RequestParam int type) {
		
		List<Users> userlist=new ArrayList<Users>();
		userlist=ur.findAll();
		if(userlist !=null) {
			for(Users usr: userlist) {
				if(usr.getId()==id) {
				ur.UpdateUserAccno(id,accno,type);
				System.out.println("updated");
				}			
			}
		}	
	}
	
	
	@PutMapping(path="/put/{id}")
	public void DelUser(@PathVariable("id") long id,@RequestBody Users user) {
		
		List<Users> userlist=new ArrayList<Users>();
		userlist=ur.findAll();
		if(userlist !=null) {
			for(Users usr: userlist) {
				if(usr.getId()==id) {
				usr.setName(user.getName());
				usr.setLastName(user.getLastName());
				ur.save(usr);
				System.out.println("updated");
				}			
			}
		}	
	}
	
	
}
