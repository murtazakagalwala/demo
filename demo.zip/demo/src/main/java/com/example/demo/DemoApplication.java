package com.example.demo;

import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.web.servlet.DispatcherServletAutoConfiguration;
import org.springframework.context.annotation.Bean;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.security.crypto.codec.Base64;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.servlet.DispatcherServlet;

import com.example.demo.controller.UserController;
import com.example.demo.entities.UserAccount;
import com.example.demo.entities.UserPhone;
import com.example.demo.entities.Users;

@SpringBootApplication
public class DemoApplication {
	
	@Bean(name = DispatcherServletAutoConfiguration.DEFAULT_DISPATCHER_SERVLET_BEAN_NAME)
	public DispatcherServlet dispatcherServlet() {
		return new LoggableDispatcherServlet();
	}
	
	public static void main(String[] args) {
		SpringApplication.run(DemoApplication.class, args);
		System.out.println("Started");		
			
		  final String uri = "http://localhost:8080/demo/";
		     
		    //Get Logic
		    HttpEntity<String> request = new HttpEntity<String>(getHeaders());
		    RestTemplate restTemplate = new RestTemplate();
		    //Users[] result = restTemplate.getForObject(uri+"get", Users[].class);
		    ResponseEntity<Users[]> result=restTemplate.exchange(uri+"get", HttpMethod.GET, request, Users[].class);
		     Users[] userresult=result.getBody();
		    for (Users results : userresult) {
				System.out.print(results.getName());
			}
			
		    
		    /*//Post Logic
		    Users user=new Users();
		    UserPhone uphone=new UserPhone();
			uphone.setPhonenumber(982117860);
			UserPhone uphone2=new UserPhone();
			uphone2.setPhonenumber(996733897);
			Set<UserPhone> upset=new HashSet<UserPhone>();
			
			UserAccount uacc=new UserAccount();
			uacc.setAccNo(123458);
			uacc.setAccType(1);
			uacc.setBalance(10000.0);
			
			UserAccount uacc2=new UserAccount();
			uacc2.setAccNo(123459);
			uacc2.setAccType(0);
			uacc2.setBalance(1000.0);
			
			Set<UserAccount> uaccset=new HashSet<UserAccount>();
			uaccset.add(uacc);
			uaccset.add(uacc2);
			upset.add(uphone);
			upset.add(uphone2);
			user.setName("Munira");
			user.setLastName("Kagalwala");
			user.setPhonenumber(upset);
			user.setAccno(uaccset);
		    
		    Users[] res = restTemplate.getForObject(uri+"get", Users[].class);
		    int flag=0;
		     
		    for (Users results : res) {
				if(user.getName().equals(results.getName()))
				{	
					flag=1;
					
				}
				
			}
		    
		    if(flag==0)
		    {
		    	restTemplate.postForObject(uri+"add", user, Users[].class); 
		    	System.out.println(" Created");
		    }
		    else
		    	System.out.println("User Already PResent");
		    
		    */
		    
		    //Delete Logic
		   /* Map<String,String> param=new HashMap<String,String>();
		    param.put("name","Munira");
		    restTemplate.delete(uri+"delete/{name}", param);*/
		   
		    
		    
		    //Put Logic
		  /*  Users putuser=new Users();
		    putuser.setName("Shabbir");
		    putuser.setLastName("Kagalwala");
		    Map<String,Integer> param=new HashMap<String,Integer>();
		    param.put("id",8);
		    restTemplate.put(uri+"put/{id}", putuser, param);*/
		    
	}

	   private static HttpHeaders getHeaders(){
		   String plainCreds = "Murtaza:password";
		    byte[] plainCredsBytes = plainCreds.getBytes();
		    byte[] base64CredsBytes = Base64.encode(plainCredsBytes);
		    String base64Creds = new String(base64CredsBytes);
		    HttpHeaders headers = new HttpHeaders();
		    headers.add("Authorization", "Basic " + base64Creds);
		    return headers;
	    }
}
