package com.example.demo.entities;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;

@Entity
public class UserPhone {
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	int id;
	@Column
	long Phonenumber;
	
	
	
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	
	public long getPhonenumber() {
		return Phonenumber;
	}
	public void setPhonenumber(long phonenumber) {
		Phonenumber = phonenumber;
	}

	@Override
	public String toString() {
		return "UserPhone [id=" + id + ", Phonenumber=" + Phonenumber + "]";
	}
}
