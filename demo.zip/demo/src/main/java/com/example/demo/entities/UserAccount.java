package com.example.demo.entities;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;


@Entity
public class UserAccount {
	
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	long id;
	
	long AccNo;
	int accType;
	double balance;
	long Users_id;
	
	
	
	public long getUsers_id() {
		return Users_id;
	}
	public void setUsers_id(long users_id) {
		Users_id = users_id;
	}
	public long getId() {
		return id;
	}
	public void setId(long id) {
		this.id = id;
	}
	public long getAccNo() {
		return AccNo;
	}
	public void setAccNo(long accNo) {
		AccNo = accNo;
	}
	public int getAccType() {
		return accType;
	}
	public void setAccType(int accType) {
		this.accType = accType;
	}
	public double getBalance() {
		return balance;
	}
	public void setBalance(double balance) {
		this.balance = balance;
	}
	
	@Override
	public String toString() {
		return "UserAccount [id=" + id + ", AccNo=" + AccNo + ", accType=" + accType + ", balance=" + balance + "]";
	}
	
	

}
