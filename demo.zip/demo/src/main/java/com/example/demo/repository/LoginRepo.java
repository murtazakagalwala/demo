package com.example.demo.repository;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.example.demo.entities.LoginInfo;

public interface LoginRepo extends JpaRepository<LoginInfo,Long> {
	@Query("select li from LoginInfo li where li.username=:username")
	Optional<LoginInfo> findByusername(@Param("username") String user);
}
