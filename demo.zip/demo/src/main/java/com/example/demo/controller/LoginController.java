package com.example.demo.controller;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.SessionAttributes;

import com.example.demo.entities.LoginInfo;
import com.example.demo.repository.LoginRepo;
import com.example.demo.repository.UserRepo;

@Controller
@SessionAttributes("name")
public class LoginController {
	
	@Autowired
	private LoginRepo lr;
	@Autowired
	private PasswordEncoder pe;
	@Autowired
	private UserRepo ur;
	
@GetMapping(path="/register")
//@ResponseBody
public String RegisterPage() {
	
	return "register";
	
}
@GetMapping(path="/login")
//@ResponseBody
public String LoginPage() {
	
	return "login";
	
}


@PostMapping(path="/login")
//@ResponseBody
public String LoginWelcomePage(@RequestParam String name,@RequestParam String password,ModelMap model) {
	Optional<LoginInfo> li=lr.findByusername(name);
	System.out.println("Inside login post mapping");
	System.out.println(li.get().getUsername());
	if(li.isPresent() && li.get().isEnabled()==true && pe.matches(password, li.get().getPassword()))
	{
		System.out.println(li.get().getUsername());
		model.addAttribute("name",ur.findAll());
		return "welcome";
	}
	return "login";
}


@PostMapping(path="/register")
public String RegisterPagePost(@RequestParam String name,@RequestParam String password,ModelMap model) {
	LoginInfo li=new LoginInfo();
	li.setEnabled(true);
	li.setRole("ROLE_user");
	li.setPassword(pe.encode(password));
	li.setUsername(name);
	lr.save(li);
	System.out.println(name+"Saved");
	
	return "login";
	
}


}
