package com.example.demo.entities;

import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;

@Entity

public class Users {
	
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	long id;
	@Column
	String name;
	@Column
	String lastName;
	@OneToMany(cascade=CascadeType.ALL)
	@JoinColumn(name="Users_id")
	Set<UserPhone> phonenumber;
	
	@OneToMany(cascade=CascadeType.ALL)
	@JoinColumn(name="Users_id")
	Set<UserAccount> accno;
	
	
	public Set<UserAccount> getAccno() {
		return accno;
	}
	public void setAccno(Set<UserAccount> accno) {
		this.accno = accno;
	}
	public long getId() {
		return id;
	}
	public void setId(long id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	public Set<UserPhone> getPhonenumber() {
		return phonenumber;
	}
	public void setPhonenumber(Set<UserPhone> phonenumber) {
		this.phonenumber = phonenumber;
	}
	
	

}
