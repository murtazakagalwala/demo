package com.example.demo.security;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.HttpMethod;
import org.springframework.security.config.annotation.authentication.builders.AuthenticationManagerBuilder;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.NoOpPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
@Configuration
@EnableWebSecurity
public class SecurityConfig extends WebSecurityConfigurerAdapter {

	@Override
	protected void configure(HttpSecurity http) throws Exception {
		// TODO Auto-generated method stub
		http
		.csrf().disable()
		.httpBasic().and()
		.authorizeRequests()
		.antMatchers(HttpMethod.PUT).hasRole("user")
		.antMatchers(HttpMethod.POST).hasAnyRole("admin","user")
		.antMatchers(HttpMethod.DELETE).hasRole("admin")
		.antMatchers(HttpMethod.GET).hasAnyRole("admin","user");
	}
	
	@Autowired
	DataSource datasource;
	@Autowired
	 public void configureGlobal(AuthenticationManagerBuilder auth) 
	            throws Exception 
	    {
			auth.jdbcAuthentication().dataSource(datasource)
			.usersByUsernameQuery("select username,password,If ( is_enabled = 1, 'true', 'false')as is_enabled from login_info where username=?")
			.authoritiesByUsernameQuery("select username,role from login_info where username=?");
			
	    }
	
    
    
	//@SuppressWarnings("deprecation")
	@Bean
	public static PasswordEncoder passwordEncoder() {
	return new BCryptPasswordEncoder();
	}
	
	
	
	
	
	
	
}
